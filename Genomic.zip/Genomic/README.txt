Step 1: Download the Visium_HD_Mouse_Brain_binned_outputs folder from https://www.10xgenomics.com/datasets/visium-hd-cytassist-gene-expression-libraries-of-mouse-brain-he

Step 2: Run the code in the DataGenerator.Rmd and DataProcessing.Rmd files. This will generate the data to be used in the simulations and experiments.

Step Derivative Benchmark: Open the Derivative_1D.ipynb file and follow the instructions.

Step Genomic Gradient Estimate: Open the HS-SVD_Genomic.ipynb file and follow the instructions.
